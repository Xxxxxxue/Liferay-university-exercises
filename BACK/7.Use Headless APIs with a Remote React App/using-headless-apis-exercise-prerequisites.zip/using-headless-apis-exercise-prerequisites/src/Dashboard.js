import React from 'react';
import Accounts from './Accounts';
import './style.css';

//Displays the completed Accounts Carousel

export default function Dashboard() {
  return(
    <div className="Dashboard">
      <Accounts />
    </div>
  );
};
