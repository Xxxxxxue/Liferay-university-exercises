AUI().ready(
	'liferay-sign-in-modal',
	function(A) {
		// Insert snippet 01-variables-and-sign-in here

		// Insert snippet 02-close-nav-click here
	}
);