package com.liferay.training.gradebook.web.constants;

/**
 * @author Liferay
 */
public class GradebookPortletKeys {

	public static final String GRADEBOOK =
		"com_liferay_training_gradebook_web_portlet_GradebookPortlet";

}