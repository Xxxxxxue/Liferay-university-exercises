/**
 * © 2017 Liferay, Inc. <https://liferay.com>
 *
 * SPDX-License-Identifier: MIT
 */

'use strict';

var gulp = require('gulp');
var liferayPluginTasks = require('liferay-theme-tasks/plugin');

liferayPluginTasks.registerTasks({
	gulp,
});
