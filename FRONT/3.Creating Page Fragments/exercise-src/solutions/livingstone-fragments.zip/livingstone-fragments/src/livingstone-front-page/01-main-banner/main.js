console.group('01-main-banner');
console.log('fragmentElement', fragmentElement);
console.groupEnd();
